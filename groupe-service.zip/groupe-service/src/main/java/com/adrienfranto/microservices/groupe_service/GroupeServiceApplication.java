package com.adrienfranto.microservices.groupe_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroupeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroupeServiceApplication.class, args);
	}

}
